class Classification:
	"""
	Determine the ratings for the vulnerability attack
	0 means  Low Risk
	10 means High Risk
	"""
	pass