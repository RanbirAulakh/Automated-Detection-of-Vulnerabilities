class Rating:
	"""
	Determine the ratings for the vulnerability attack
	0 means  Low Risk
	10 means High Risk
	"""
	display_folders_files = 5
	xss = 10
	sql_injection = 10


	def SQL_Injection(self):
		return self.SQL_Injection

	# def File_Listing()